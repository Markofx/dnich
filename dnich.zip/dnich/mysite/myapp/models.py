from django.db import models

# Create your models here.

class Kukja(models.Model):
    name = models.CharField(max_length=30)

class Book(models.Model):
    name = models.CharField(max_length=30)
    pages = models.IntegerField()
    price = models.IntegerField()
    slika = models.ImageField(upload_to='index/', blank=True)
    kukja = models.ForeignKey(Kukja, on_delete=models.CASCADE, null=True)

