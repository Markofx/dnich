from django.shortcuts import redirect, render,HttpResponse
from .models import Book


# Create your views here.
def base(request):
    return render(request,'base.html')

def index(request):
    books = Book.objects.all()
    return render(request,'index.html',{'books':books})

def kniga(request,pk):
    kniga = Book.objects.get(id=pk)
    if kniga is not None:
        return render(request, 'details.html', {'book':kniga})

